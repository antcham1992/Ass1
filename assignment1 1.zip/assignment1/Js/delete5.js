﻿let x = document.getElementById("btn");
x.addEventListener("click", function () {
    x.innerHTML = window.location.href = "viewassiments.html"
   

});
x.addEventListener("click", function () {
    alert("Διαγράφηκε επιτυχώς");

});
