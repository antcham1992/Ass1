﻿let x = document.getElementById("btn");
x.addEventListener("click", function () {
    x.innerHTML = window.location.href = "View_trainers_per_course.html"
   

});
x.addEventListener("click", function () {
    alert("Διαγράφηκε επιτυχώς");

});
