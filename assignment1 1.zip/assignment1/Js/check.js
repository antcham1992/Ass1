﻿function save() {
    
    let x = document.getElementById("input3").value;
    let y = document.getElementById("input").value;
    let btn = document.getElementById("button");
    if (x != "" && x >= 15 && y != "") {
        btn.innerHTML = window.location.href = `viewassiment_per_course.html`
       alert("Οι αλλαγές έγιναν επιτυχώς");
        
    }
    else {
        
            alert("Δοκιμάστε ξανά");
    }
    changeStyle(x, y);

}
function changeStyle(x,y) {
    //Αλλαζει το χρωμα σε περιπτωση καποιο απο τα στοιχεια που εισαγει ο χρηστης ειναι στελνοντας του μύνημα λαθους

    
    if (x == ""||x<15) {
        document.getElementById("input3").style.backgroundColor = "red";
        document.getElementById("p3").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (y == "") {
        document.getElementById("input").style.backgroundColor = "red";
        document.getElementById("p1").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
   
    blockbutton();
}