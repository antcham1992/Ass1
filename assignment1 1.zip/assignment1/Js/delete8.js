﻿let x = document.getElementById("btn");
x.addEventListener("click", function () {
    x.innerHTML = window.location.href = "viewassiments_per_student_per_course.html"
   

});
x.addEventListener("click", function () {
    alert("Διαγράφηκε επιτυχώς");

});
