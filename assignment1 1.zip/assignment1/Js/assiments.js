﻿
function assiment() {
    let assiment = ["Assignment_Part_A", "Assignment_Part_B", "Assignment_Part_C", "Assignment_Part_D", "Assignment_Part_E", "Assignment_Part_F", "Assignment_Part_G", "Assignment_Part_H"];
    return assiment;
}

function checkInput() {
    // έλεγχος assignment
    let i;
    let a = assiment();
    let assim;
    let title = document.getElementById("input").value;
    let text = document.getElementById("input1").value;
    let date = document.getElementById("input2").value;
    let score1 = document.getElementById("input3").value;
    let score2 = document.getElementById("input4").value;
    let s1=Score(score1);
    let s2 = Score(score2)
    let btn = document.getElementById("button");
    let check = characterInput(text);
    for (i = 0; i < a.length; i++) {
        assim = a[i];
        if (assim != title) {
            continue;
        }
        if (assim == title && check == true && date >= "2021- 11-09"&&s1==true&&s2==true) {
            method(btn);
            alert("Το assiment αποθηκεύτηκε με επιτυχία");
            break;

        }

    }
    if (assim != title || check == false||date < "2021- 11-09" || s1 == false ||s2 == false) {
        alert("Ξαναδοκιμάστε");
        changeStyle(assim,title,check,date,s1,s2);
    }
}
function changeStyle(x, y, z,l,n,m) {
    //Αλλαζει το χρωμα σε περιπτωση καποιο απο τα στοιχεια που εισαγει ο χρηστης ειναι στελνοντας του μύνημα λαθους

    if (x != y) {
        document.getElementById("input").style.backgroundColor = "red";
        document.getElementById("p1").innerText = "Συμπληρώστε ξανά το πεδίο"

    }
    if (z==false) {
        document.getElementById("input1").style.backgroundColor = "red";
        document.getElementById("p2").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (l < "2021- 11-09") {
        document.getElementById("input2").style.backgroundColor = "red";
        document.getElementById("p3").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (n == false) {
        document.getElementById("input3").style.backgroundColor = "red";
        document.getElementById("p4").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (m == false) {
        document.getElementById("input4").style.backgroundColor = "red";
        document.getElementById("p5").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    blockbutton();
}
function blockbutton() {
    //μπλοκαρει το κουμπι οταν ο χρηστης εισαγει λαθος δεδομενα
    document.getElementById("button").disabled = true;
}
function method(btn) {
    // μεταφερει τον χρηστη σε καινουργιο παραθυρο σε περίπτωση που τα στοιχεια του είναι σωστα
    btn.innerHTML = window.location.href = "viewassiments.html"

}
function Score(x) {
    if (x >= 0 && x <= 100&&x!="") {
        return true;
    }
    else {
        return false;
    }
}

function characterInput(x) {
    // ελεγχος για την περιοχη textarea
    let check = /^[a-z0-9]+$/;
    if (x.match(check)) {
        return true;
    } else {
        return false;
    }
}
