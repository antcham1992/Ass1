﻿
function student(name, lastname,birthday,fees) {
    this.name = name;
    this.lastname = lastname;
    this.birthday = birthday;
    this.fees = fees;
}

function createStudents() {
    let s1 = new student("Bill", "Orfanos", "1980-08-26", 2000);
    let s2 = new student("Theodoros", "Doe", "1990-01-16", 5000);
    let s3 = new student("Pinelopi", "Xatzaki", "1992-05-08", 7000);
    let s4 = new student("Axileas", "Stefanidis", "1997-12-08", 8000);
    let s5 = new student("Kostas", "Kalotinis", "1997-12-08", 1500);
    let s6 = new student("Dimitris", "Anastasios", "1987-02-18", 400);
    let s7 = new student("Mpampis", "Goudis", "1988-02-18", 5000);
    let s8 = new student("kiki", "Dimoula", "1988-12-28", 9500);
    let s9 = new student("Hlias", "Lamprou", "1988-12-28", 6000);
    let s10 = new student("Anna", "Pappa", "1994-10-05", 3000);
    let s = [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10];
    return s;
}

function students() {
    let item;
    let student = createStudents();
    let name = document.getElementById("input").value;
    let lastname = document.getElementById("input1").value;
    let birthday = document.getElementById("input2").value;
    let fees = document.getElementById("input3").value;
    let stuName;
    let stuLname;
    let stuBirthday;
    let stuFees;
    let btn = document.getElementById("button");
    for (item of student) {
        stuName = item.name;
        stuLname = item.lastname;
        stuBirthday = item.birthday;
        stuFees = item.fees
        if (stuName != name && stuLname != lastname) {
            continue;
        }
        
        if (stuName == name && stuLname == lastname && stuBirthday == birthday && stuFees==fees) {
            
            method(btn);
                alert("Oι αλλαγές αποθηκεύτηκαν με επιτυχία");
                break;
            }
           
        }
       
    if (stuName != name || stuLname != lastname || stuBirthday != birthday || stuFees != fees) {
        alert("Ξαναδοκιμάστε");
        changeStyle(stuName,name,stuLname,lastname, stuBirthday, birthday, stuFees,fees);
    }

    }
function changeStyle(x, y, z, l, n,m,t,r) {
    //Αλλαζει το χρωμα σε περιπτωση καποιο απο τα στοιχεια που εισαγει ο χρηστης ειναι στελνοντας του μύνημα λαθους

    if (x!= y) {
        document.getElementById("input").style.backgroundColor = "red";
        document.getElementById("p").innerText = "Συμπληρώστε ξανά το πεδίο"
        

    }
   if (z!=l) {
        document.getElementById("input1").style.backgroundColor = "red";
        document.getElementById("p1").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
   if (n!=m) {
        document.getElementById("input2").style.backgroundColor = "red";
        document.getElementById("p2").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (t!=r) {
        document.getElementById("input3").style.backgroundColor = "red";
        document.getElementById("p3").innerHTML = "Συμπληρώστε ξανά το πεδίο "
    }
    blockbutton();
}

function blockbutton() {
    //μπλοκαρει το κουμπι οταν ο χρηστης εισαγει λαθος δεδομενα
    document.getElementById("button").disabled = true;
}

function method(btn) {
    // μεταφερει τον χρηστη σε καινουργιο παραθυρο σε περίπτωση που τα στοιχεια του είναι σωστα
    btn.innerHTML = window.location.href = "viewstudent.html"

}