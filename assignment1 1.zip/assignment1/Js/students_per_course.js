﻿
function student(name, lastname) {
    this.name = name;
    this.lastname = lastname;
    
}

function createStudents() {
    let s1 = new student("Bill", "Orfanos");
    let s2 = new student("Theodoros", "Doe");
    let s3 = new student("Pinelopi", "Xatzaki");
    let s4 = new student("Axileas", "Stefanidis");
    let s5 = new student("Kostas", "Kalotinis");
    let s6 = new student("Dimitris", "Anastasios");
    let s7 = new student("Mpampis", "Goudis");
    let s8 = new student("kiki", "Dimoula");
    let s9 = new student("Hlias", "Lamprou");
    let s10 = new student("Anna", "Pappa");
    let s = [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10];
    return s;
}


function checkInput(course,stream) {
    // έλεγχος μαθημάτων
    let courses = ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"];
    let i;
   
    for (i = 0; i < courses.length; i++) {
        if (courses[i] != course) {
            continue;
        }
        if (courses[i] == course && stream >= 15 ) {

            return true;
            break;

        }

    }
    if (courses[i] != course || stream < 15 ) {
        return false;
        
    }
}
function students() {
    let item;
    let student = createStudents();
    let name = document.getElementById("input").value;
    let lastname = document.getElementById("input1").value;
    let course = document.getElementById("input2").value;
    let stream = document.getElementById("input3").value;
    let check = checkInput(course, stream);
    let stuName;
    let stuLname;
    let btn = document.getElementById("button");
    for (item of student) {
        stuName = item.name;
        stuLname = item.lastname ;
        if (stuName != name && stuLname != lastname) {
            continue;
        }
        
        if (stuName == name && stuLname == lastname && check== true) {
            
               method(btn);
                alert("Oι αλλαγές αποθηκεύτηκαν με επιτυχία");
                break;
            }
           
        }
       
    if (stuName != name || stuLname != lastname || check == false) {
        alert("Ξαναδοκιμάστε");
        changeStyle(stuName, name, stuLname, lastname, check);
    }
   
}
function changeStyle(x, y, z, l, n) {
    //Αλλαζει το χρωμα σε περιπτωση καποιο απο τα στοιχεια που εισαγει ο χρηστης ειναι στελνοντας του μύνημα λαθους

    if (x != y) {
        document.getElementById("input").style.backgroundColor = "red";
        document.getElementById("p").innerText = "Συμπληρώστε ξανά το πεδίο"

    }
    if (z != l) {
        document.getElementById("input1").style.backgroundColor = "red";
        document.getElementById("p1").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (n == false) {
        document.getElementById("input2").style.backgroundColor = "red";
        document.getElementById("input3").style.backgroundColor = "red";
        document.getElementById("p2").innerText = "To ονομα μαθηματος και ο κωδικος πρέπει να ειναι σωστα";
        document.getElementById("p3").innerText = "To ονομα μαθηματος και ο κωδικος πρέπει να ειναι σωστα";
    }
    blockbutton();
}
function blockbutton(m) {
    //μπλοκαρει το κουμπι οταν ο χρηστης εισαγει λαθος δεδομενα
    document.getElementById("button").disabled = true;
}
        
function method(btn) {
    // μεταφερει τον χρηστη σε καινουργιο παραθυρο σε περίπτωση που τα στοιχεια του είναι σωστα
    btn.innerHTML = window.location.href = "View_students_per_course.html"

}