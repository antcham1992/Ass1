﻿
function trainer(name, lastname,subject) {
    this.name = name;
    this.lastname = lastname;
    this.subject = subject;
}

function createTrainers() {
    let t1 = new trainer("Hector", "Gkatsos", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t2 = new trainer("john", "Doe", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t3 = new trainer("Helene", "Xatzaki", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t4 = new trainer("Leonidas", "Stefanidis", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t5 = new trainer("Andreas", "Orfanos", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t6 = new trainer("George", "Abramidis", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t7 = new trainer("Philippos", "Goudis", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t8 = new trainer("Lazaros", "Lamprou", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t9 = new trainer("kiki", "Dimou", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t10 = new trainer("Eirini", "Pappa", ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"]);
    let t = [t1, t2, t3, t4, t5, t6, t7, t8, t9, t10];
    return t;
}

function trainers() {
    let subj;
    let item;
    let trainer = createTrainers();
    let name = document.getElementById("input").value;
    let lastname = document.getElementById("input1").value;
    let subject = document.getElementById("input2").value;
    let stream = document.getElementById("input3").value;
    let btn = document.getElementById("button");
    let tN;
    let tL;
    let tS;
    for (item of trainer) {
        tN = item.name;
        tL = item.lastname;
        if (tN != name && tL!= lastname) {
            continue;
        }
        
        if (tN == name && tL == lastname && stream >= 15) {
            for (subj of item.subject) {
                tS = subj;
                if (subject != tS) {
                    continue;
                }
                if (subject == tS) {
                    method(btn);
                    alert("Oι αλλαγές αποθηκεύτηκαν με επιτυχία");
                    break;
                }
                
            }
            break;
        }
      
    }
    if (tN != name || tL!= lastname || subject != tS||stream<15) {
        alert("Ξαναδοκιμάστε");
        changeStyle(tN,name,tL,lastname ,tS,subject,stream);
    }
}
function changeStyle(x, y, z, l, n,m,o) {
    //Αλλαζει το χρωμα σε περιπτωση καποιο απο τα στοιχεια που εισαγει ο χρηστης ειναι στελνοντας του μύνημα λαθους

    if (x != y) {
        document.getElementById("input").style.backgroundColor = "red";
        document.getElementById("p1").innerText = "Συμπληρώστε ξανά το πεδίο"

    }
    if (z != l) {
        document.getElementById("input1").style.backgroundColor = "red";
        document.getElementById("p2").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (n != m) {
        document.getElementById("input2").style.backgroundColor = "red";
        document.getElementById("p3").innerText = "Συμπληρώστε ξανά το πεδίο"
    }

    if (o< 15) {
        document.getElementById("input3").style.backgroundColor = "red";
        document.getElementById("p4").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    
    
    blockbutton();
}
function blockbutton() {
    //μπλοκαρει το κουμπι οταν ο χρηστης εισαγει λαθος δεδομενα
    document.getElementById("button").disabled = true;
}

function method(btn) {
    // μεταφερει τον χρηστη σε καινουργιο παραθυρο σε περίπτωση που τα στοιχεια του είναι σωστα
    btn.innerHTML = window.location.href = "View_trainers_per_course.html"

}