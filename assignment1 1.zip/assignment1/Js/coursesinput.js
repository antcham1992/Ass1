﻿
function Lessons() {
    // Δημιουργία πίνακα μαθημάτων
   let courses= ["C#", "Python", "Javascript", "Java", "HTML / CSS", "Angular / React", "SQL", "Algorithms"];
    return courses;
}

function checkInput() {
    // έλεγχος μαθημάτων 
    let courses = Lessons();
    let array
    let course = document.getElementById("input").value;
    let stream = document.getElementById("input2").value;
    let date1 = document.getElementById("input3").value;
    let date2 = document.getElementById("input4").value;
    let btn = document.getElementById("button");
    let date3 = date(date1, date2);
    for (let i = 0; i <courses.length; i++) {
        array = courses[i]
        if (array!= course) {
            
            continue;
        }
        if (array == course && stream >= 15 && date1 >= "2017-01-01" && date3 == true) {
            method(btn);
            alert("Το μάθημα αποθηκεύτηκε με επιτυχία");
            
            break;

        }

    }

    if (array !==course || stream < 15 || date1 < "2017-01-01" || date3 == false) {
        alert("Ξαναδοκιμάστε")
       
        changeStyle(array,course,stream,date1,date3);

    }
   
}
function changeStyle(x,y,z,l,n) {
   //Αλλαζει το χρωμα σε περιπτωση καποιο απο τα στοιχεια που εισαγει ο χρηστης ειναι στελνοντας του μύνημα λαθους
    
    if (x!=y) {
        document.getElementById("input").style.backgroundColor = "red";
        document.getElementById("p1").innerText = "Συμπληρώστε ξανά το πεδίο"
        
    }
    if (z < 15) {
        document.getElementById("input2").style.backgroundColor = "red";
        document.getElementById("p2").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (l < "2017-01-01"||l=="") {
        document.getElementById("input3").style.backgroundColor = "red";
        document.getElementById("p3").innerText = "Συμπληρώστε ξανά το πεδίο"
    }
    if (n==false ||n=="") {
        document.getElementById("input4").style.backgroundColor = "red";
        document.getElementById("p4").innerHTML = "Συμπληρώστε ξανά το πεδίο η τελική ημ/νια πρέπει να ειναι μετα <br/> 3 ή 6 μήνες της αρχικής"
    }
    blockbutton();
}
function blockbutton() {
    //μπλοκαρει το κουμπι οταν ο χρηστης εισαγει λαθος δεδομενα
    document.getElementById("button").disabled = true;
}
function date(date1, date2) {
    // ελεγχος για το εαν η τελικη ημερομηνια ειναι μεγαλυτερη κατα 3 η εξι μηνες της αρχικης
    let d1 = new Date(date1);
    let d2 = new Date(date2);
    let d = String(d1.getDate()).padStart(2, '0');
    let m= d1.getMonth()+1;
    let y= d1.getFullYear();
    let dd = String(d2.getDate()).padStart(2, '0');
    let mm = d2.getMonth()+1;
    let yy = d2.getFullYear();

    if (dd==d&&(mm == m+6||mm==m+3)&& yy == y) {
        
        return true;
    }
    else {
        return false;
    }
}


function method(btn) {
    // μεταφερει τον χρηστη σε καινουργιο παραθυρο σε περίπτωση που τα στοιχεια του είναι σωστα
    btn.innerHTML = window.location.href = "viewcourses.html"
    
}
         

      



